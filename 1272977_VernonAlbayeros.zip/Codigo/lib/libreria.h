#ifndef __LIB_INCLUDED__
#define __LIB_INCLUDED__

#include "debug.h"
#include "image_png.h"
#include "keyboard.h"
#include "mouse.h"
#include "sprites.h"
#include "video.h"
#include "sound.h"
#include <string.h>

// ------------------------------------------------------------------------------------------------
//
// ------------------------------------------------------------------------------------------------

#define TRUE                                                1
#define FALSE                                               0

#endif

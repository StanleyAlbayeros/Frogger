#include <stdio.h>      /* printf */
#include <stdlib.h>     /* system */

void mostraMenuPrincipal();
void mostraMenuNivellDificultat();
void mostraMenuanimacions();
